package com.example.mycalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private StringBuilder currentInput;
    private String operator;
    private Double operand1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        currentInput = new StringBuilder();
        operator = "";
        operand1 = null;

        GridLayout gridLayout = findViewById(R.id.gridLayout);

        for (int i = 0; i < gridLayout.getChildCount(); i++) {
            View child = gridLayout.getChildAt(i);

            if (child instanceof Button) {
                Button button = (Button) child;
                button.setOnClickListener(view -> onButtonClick(button.getText().toString()));
            }
        }
    }

    private void onButtonClick(String buttonText) {
        switch (buttonText) {
            case "=":
                performCalculation();
                break;
            case "+":
            case "-":
            case "*":
            case "/":
                setOperator(buttonText);
                break;
            case "C": // Added for clear (delete) button
                clearInput();
                break;
            default:
                appendToInput(buttonText);
                break;
        }
    }

    private void appendToInput(String input) {
        currentInput.append(input);
        editText.setText(currentInput.toString());
    }

    private void setOperator(String newOperator) {
        operator = newOperator;
        if (operand1 == null) {
            operand1 = Double.valueOf(currentInput.toString());
            currentInput.setLength(0);
        }
    }

    private void performCalculation() {
        if (operator.isEmpty() || operand1 == null || currentInput.length() == 0) {
            return;
        }

        double operand2 = Double.valueOf(currentInput.toString());
        double result = 0;

        switch (operator) {
            case "+":
                result = operand1 + operand2;
                break;
            case "-":
                result = operand1 - operand2;
                break;
            case "*":
                result = operand1 * operand2;
                break;
            case "/":
                if (operand2 != 0) {
                    result = operand1 / operand2;
                } else {
                    editText.setText("Error");
                    return;
                }
                break;
        }

        currentInput.setLength(0);
        currentInput.append(new DecimalFormat("#.######").format(result));
        editText.setText(currentInput.toString());

        operand1 = result;
        operator = "";
    }

    private void clearInput() {
        currentInput.setLength(0);
        editText.setText("");
        operand1 = null;
        operator = "";
    }
}

